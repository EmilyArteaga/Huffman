/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package final_programacion3_huffman;

import final_programacion3_huffman.src.gui.Principal;

/**
 *
 * @author BeLeN
 */
public class Final_Programacion3_Huffman {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.setVisible(true);
    }
    
}
